[Project homepage](https://peter88213.github.io/yw2md)


The yw2md Python script runs through all chapters and scenes of a yWriter 6/7 project and fills markdown templates.

## Usage
usage: `yw2md.py [-h][--silent] Project`

#### positional arguments:
  `Project`          yWriter project file

#### optional arguments:
  `-h, --help`       show a help message and exit
  
  `--silent`         suppress error messages and the request to confirm overwriting

